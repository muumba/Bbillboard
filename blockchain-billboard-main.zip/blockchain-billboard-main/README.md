# BlockchainBillboard, NFT Advertisements
<!--
*** Thanks for checking out this README Template. If you have a suggestion that would
*** make this better, please fork the repo and create a pull request or simply open
*** an issue with the tag "enhancement".
*** Thanks again! Now go create something AMAZING! :D
-->

<!-- PROJECT SHIELDS -->
<!--
*** I'm using markdown "reference style" links for readability.
*** Reference links are enclosed in brackets [ ] instead of parentheses ( ).
*** See the bottom of this document for the declaration of the reference variables
*** for contributors-url, forks-url, etc. This is an optional, concise syntax you may use.
*** https://www.markdownguide.org/basic-syntax/#reference-style-links
-->
[![MIT License][license-shield]][license-url]

<!-- PROJECT LOGO -->
<br />
<p align="center">

  <h3 align="center">BlockchainBillboard - GitHub Repository</h3>

  <p align="center">
    💜🌍
    <br />
    <a href=""><strong>Welcome to the Docs!</strong></a>
    <br />
    <br />
    <a href="">Report Bug</a>
    ·
    <a href="">Request Feature</a>
  </p>
</p>


<!-- ABOUT THE PROJECT -->
## About The Project

Advertise on the world's first NFT-backed digital billboard where each advertisement is backed by a non-fungible token minted from a verifiable ERC-721 smart contract.

Each Token (NFT Advertisement) will have the following Metadata: 

Title
Description
Company Website
Industry
Advertisement Image
Advertisement Slot Position.
Each token will have a unique TokenId between 1 and 100, equivalent to the advertisement's slot position. This is precisely how we will create one-to-one ownership for EACH advertisement published on the BlockchainBillboard.

Each advertisement slot position is backed by an NFT that verifies your right to your selected slot position. Starting from the top, we decided to go with a Half-Ether drop in price for every second row.

To kickstart things, we randomly scattered 10 FREE advertisement spots on the BlockchainBillboard.

The total supply is programmatically capped at 100 tokens. Our smart contract will immediately hault the issuing of further NFT Advertisements once the BlockchainBillboard reaches peak capacity.

You do not have to take our word for it; we recommend that you verify for yourself.

Smart Contract: https://rinkeby.etherscan.io/address/0x1807D2c2Dfa372AD31EeaB48C38Bb104a254d68A

### Built With

JavaScript/ReactJS, Bootstrap, Solidity, IPFS, OpenZeppelin, Truffle, MetaMask API

<!-- LICENSE -->
## License

Distributed under the MIT License. See `LICENSE` for more information.

<!-- ACKNOWLEDGEMENTS -->
## Acknowledgements

Check out dApp Univeristy on Youtube! Gregory is the OG of dApp development :)


<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->
[forks-shield]: https://img.shields.io/github/forks/othneildrew/Best-README-Template.svg?style=flat-square
[stars-shield]: https://img.shields.io/github/stars/othneildrew/Best-README-Template.svg?style=flat-square
[issues-shield]: https://img.shields.io/github/issues/othneildrew/Best-README-Template.svg?style=flat-square
[license-shield]: https://img.shields.io/github/license/othneildrew/Best-README-Template.svg?style=flat-square
[license-url]: https://github.com/muumba/blockchain-billboard/blob/main/LICENSE
[linkedin-shield]: https://img.shields.io/badge/-LinkedIn-black.svg?style=flat-square&logo=linkedin&colorB=555
