import React, { Component, useState, useEffect} from 'react';
import { Link } from 'react-router-dom'
import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import Col from 'react-bootstrap/Col'
import Form from 'react-bootstrap/Form'
import Spinner from 'react-bootstrap/Spinner'
import Tippy from '@tippy.js/react'
import Alert from 'react-bootstrap/Alert'
import { store } from 'react-notifications-component';
import ipfs from './../ipfs'

const token = {
  "name": "",
  "description": "",
  "image": "",
  "external_link": "https://www.blockchainbillboard.io/",
  "attributes": [
    {
      "trait_type": "Industry", 
      "value": ""
    },
    {
      "trait_type": "Blockchain Billboard", 
      "value": ""
    },
    {
      "display_type": "number", 
      "trait_type": "Original", 
      "value": 1
    }
  ]
}

function simulateNetworkRequest() {
  return new Promise((resolve) => setTimeout(resolve, 3500));
}

const FormExample = (props) => {

  const [buffer, setBuffer] = useState('');
  const [tokenID, setTokenID] = useState(0);
  const [currentSlot, setCurrentSlot] = useState('');
  const [currentPrice, setCurrentPrice] = useState('');
  const [etherscanReceipt, setEtherscanReceipt] = useState('');
  const [metadataEndpoint, setMetadataEndpoint] = useState('');
  const [validated, setValidated] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [isLoading2, setLoading2] = useState(false);
  const [cannotProcess, setCannotProcess] = useState(false);
  const [isFinishedUploading, setFinishedUploading] = useState(false);
  const [isFinishedIssuing, setFinishedIssuing] = useState(false);
  
  useEffect(() => {
    if (isLoading) {
      simulateNetworkRequest().then(() => {
        setLoading(false);
      });
    }
  }, [isLoading]);
  
  const callContract = (metadata, tokenID) => {
    console.log(props.contract)
    setLoading2(true)
    props.contract.methods.mint(metadata, tokenID).send({
      from: props.account,
      value: props.eth_instance.utils.toWei(currentPrice, 'ether')
    })
    .once('transactionHash', (hash) => {
      setEtherscanReceipt('https://rinkeby.etherscan.io/tx/' + hash)
    })
    .once('receipt', (receipt) => {
      setLoading2(false)
      setFinishedIssuing(true)
      postNotification("Transaction Success 😃", 'NFT Advertisement was issued!', 'success', 10000)
      console.log(receipt)
    })
    .catch((error) => {
      setLoading2(false)
      if (error['code'] !== 4001) {
        setCannotProcess(true)
        postNotification("Transaction Failure 🥺", 'NFT Advertisement was not issued!', 'danger', 10000)
      } 
      console.log(error)
    });
  }
  const handleChange = event => {
    if (isFinishedUploading) {
      window.location.reload();
    }
    var currentSlot = parseInt(event.target.value);
    let displayPrice = '-1';
    if (currentSlot === 2 || currentSlot === 14 || currentSlot === 22 || currentSlot === 34 || currentSlot === 42 || currentSlot === 54 || currentSlot === 62 || currentSlot === 74 || currentSlot === 82 || currentSlot === 94) {
      displayPrice = '0'
    } else {
      if (0 < currentSlot && currentSlot <= 10) {
        displayPrice = '5'
      } else if (10 < currentSlot && currentSlot <= 20) {
        displayPrice = '4.5'
      } else if (20 < currentSlot && currentSlot <= 30) {
        displayPrice = '4.0'
      } else if (30 < currentSlot && currentSlot <= 40) {
        displayPrice = '3.5'
      } else if (40 < currentSlot && currentSlot <= 50) {
        displayPrice = '3.0'
      } else if (50 < currentSlot && currentSlot <= 60) {
        displayPrice = '2.5'
      } else if (60 < currentSlot && currentSlot <= 70) {
        displayPrice = '2.0'
      } else if (70 < currentSlot && currentSlot <= 80) {
        displayPrice = '1.5'
      } else if (80 < currentSlot && currentSlot <= 90) {
        displayPrice = '1.0'
      } else if (90 < currentSlot && currentSlot <= 100) {
        displayPrice = '0.5'
      }
    }
    setCurrentSlot(currentSlot)
    setCurrentPrice(displayPrice)
  }

  const onDrop = event => {
    const file = event.target.files[0]
    const reader = new window.FileReader()
    reader.readAsArrayBuffer(file)
    reader.onloadend = () => {
      var buffer = Buffer.from(reader.result)
      setBuffer(buffer)
    }
  }

  const postNotification = (title, message, type, duration) => {
    store.addNotification({
      title: title,
      message: message,
      type: type,
      insert: "bottom",
      container: "bottom-left",
      animationIn: ["animate__animated", "animate__fadeIn"],
      animationOut: ["animate__animated", "animate__fadeOut"],
      dismiss: {
        duration: duration,
        onScreen: true
      }
    });
  }

  const handleSubmit = event => {
    event.preventDefault()
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    setValidated(true);
    // console.log('~~~~')
    // console.log(form.walletAddress.value)
    // console.log(form.title.value)
    // console.log(form.websiteURL.value)
    // console.log(form.description.value)
    // console.log(form.slotPosition.value)
    // console.log(buffer)
    // console.log('~~~~')
    if (    buffer.length > 0 &&
            form.websiteURL.value &&
            form.slotPosition.value &&
            form.title.value &&
            form.description.value &&
            form.industry.value   ) {
      setLoading(true);
      postNotification("Uploading to IPFS 🚀", "Storing your metadata...", "success", 3500)
      ipfs.files.add(buffer, (error, result) => {
        if (error) {
          return
        }
        token.name = form.title.value
        token.description = form.description.value + "\n\n" + form.websiteURL.value
        token.attributes[0]['value'] = form.industry.value
        token.image = 'https://ipfs.io/ipfs/' + result[0].hash
        token.attributes[1]['value'] = "#" + form.slotPosition.value
        console.log(token)
        ipfs.files.add(Buffer.from(JSON.stringify(token)))
        .then(res => {
          console.log(res)
          const metaDataLink = 'https://ipfs.io/ipfs/'+ res[0].hash
          console.log(metaDataLink)
          setMetadataEndpoint(metaDataLink)
          setTokenID(form.slotPosition.value)
          setFinishedUploading(true);
        })
      })
    } else {
      console.log("all 5 forms were not filled")
    }
  }

  return (
    <div>
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <Form.Row>
          <Form.Group as={Col} md="6" controlId="walletAddress">
            <Form.Label>Wallet Address</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder=""
              defaultValue={props.account}
              disabled
            />
            <Form.Text className="text-muted">
            Thank you for connecting your wallet
            </Form.Text>
          </Form.Group>
          <Form.Group as={Col} md="6" controlId="title">
            <Form.Label>* Title</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter a title for your NFT Advertisement"
              required
            />
            <Form.Text className="text-muted">
            What is a great title for your advertisement?
            </Form.Text>
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group as={Col} md="6" controlId="websiteURL">
            <Form.Label>* Company Website URL </Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter your company's website here"
              required
            />
            <Form.Text className="text-muted">
            Which website would you like to advertise?
            </Form.Text>
          </Form.Group> 
          <Form.Group as={Col} md="6" controlId="description">
            <Form.Label>* Description</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter a description for you NFT Advertisement"
              required
            />
            <Form.Text className="text-muted">
            How would you describe your advertisement?
            </Form.Text>
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group as={Col} md="6" controlId="slotPosition">
            <Form.Label>* Advertisement Slot Position </Form.Label>
            <Form.Control required as="select" onChange={(e) => handleChange(e)} custom>
              <option label="~" defaultValue hidden></option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
              <option>6</option>
              <option>7</option>
              <option>8</option>
              <option>9</option>
              <option>10</option>
              <option>11</option>
              <option>12</option>
              <option>13</option>
              {/* <option>14</option> */}
              <option>15</option>
              <option>16</option>
              <option>17</option>
              <option>18</option>
              <option>19</option>
              <option>20</option>
              <option>21</option>
              <option>22</option>
              <option>23</option>
              <option>24</option>
              <option>25</option>
              <option>26</option>
              <option>27</option>
              <option>28</option>
              <option>29</option>
              <option>30</option>
              <option>31</option>
              <option>32</option>
              <option>33</option>
              <option>34</option>
              <option>35</option>
              <option>36</option>
              <option>37</option>
              <option>38</option>
              <option>39</option>
              <option>40</option>
              <option>41</option>
              <option>42</option>
              <option>43</option>
              <option>44</option>
              <option>45</option>
              <option>46</option>
              <option>47</option>
              <option>48</option>
              <option>49</option>
              <option>50</option>
              <option>51</option>
              <option>52</option>
              <option>53</option>
              <option>54</option>
              <option>55</option>
              <option>56</option>
              <option>57</option>
              <option>58</option>
              <option>59</option>
              <option>60</option>
              <option>61</option>
              <option>62</option>
              <option>63</option>
              <option>64</option>
              <option>65</option>
              <option>66</option>
              <option>67</option>
              <option>68</option>
              <option>69</option>
              <option>70</option>
              <option>71</option>
              <option>72</option>
              <option>73</option>
              <option>74</option>
              <option>75</option>
              <option>76</option>
              <option>77</option>
              <option>78</option>
              <option>79</option>
              <option>80</option>
              <option>81</option>
              <option>82</option>
              <option>83</option>
              <option>84</option>
              <option>85</option>
              <option>86</option>
              <option>87</option>
              <option>88</option>
              <option>89</option>
              <option>90</option>
              <option>91</option>
              <option>92</option>
              <option>93</option>
              <option>94</option>
              <option>95</option>
              <option>96</option>
              <option>97</option>
              <option>98</option>
              <option>99</option>
              <option>100</option>
            </Form.Control>
            <Form.Text className="text-muted">
            Which slot position would you prefer on the Blockchain Billboard?
            </Form.Text>
          </Form.Group>
          <Form.Group as={Col} md="6" controlId="industry">
            <Form.Label>* Industry</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter your company's industry here"
              required
            />
            <Form.Text className="text-muted">
            Which industry are you working in?
            </Form.Text>
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group as={Col} md="6" controlId="advertisement">
            <Form.Label>* Advertisement Image</Form.Label>
              <Form.File 
                required
                id="advertisement"
                label="Upload your advertisement"
                data-browse="Click me!"
                onChange={(e) => onDrop(e)}
                custom
              />
            <Form.Text className="text-muted">
            We only support PNG/JPG/GIF image format
            </Form.Text>
          </Form.Group>
          <Form.Group as={Col} md="6" controlId="cost">
            <Form.Label>Final Price</Form.Label>
            <Tippy content={"Excluding Gas Fees"} delay={100} placement={'right'} >
            <div>
            <Form.Control
                required
                type="text"
                placeholder=""
                value={currentPrice + " ETH"}
                disabled
              />
              </div>
              </Tippy>
          </Form.Group>
        </Form.Row>
        <Form.Group controlId="confirm">
          <div style={{display: 'none'}}>
            <Form.Check
              required
              id="confirm"
              label="..."
              custom
            />
          </div>
        </Form.Group>
        <Form.Group controlId="upload">
          <Form.Row>
            <Form.Label className="text-muted">You will first need to upload your metadata to the <a target="_blank" rel="noreferrer" style={{color: '#CA5010'}} href="https://en.wikipedia.org/wiki/InterPlanetary_File_System">InterPlanetary File System</a>.</Form.Label>
            <Tippy content={"🚀"} delay={100} placement={'right'} >
              <Button 
                className="btn btn-lg btn-block"
                type="submit"
                disabled={isFinishedUploading || isLoading || props.networkId !== 4}
                variant="outline-dark">
                { isFinishedUploading && !isLoading &&
                    <div> 
                      Successfully Uploaded to IPFS
                    </div>
                }
                { !isFinishedUploading && !isLoading &&
                    <div> 
                      Upload to IPFS 🚀
                    </div>
                }
                { isLoading && 
                  <div> 
                    <Spinner animation="border" size="sm" variant="dark" />
                    &nbsp;&nbsp;Uploading to IPFS
                  </div>
                }
              </Button>
            </Tippy>
          </Form.Row>
        </Form.Group>
      </Form>
    {
      <Form.Group>
        <Form.Row>
          <Form.Label className="text-muted">Issue your NFT Advertisement and gain verifiable rights to slot position (#{currentSlot}) on the <Link to="/" style={{color: '#CA5010'}}>BlockchainBillboard</Link>.</Form.Label>
          <Tippy content={"🛠️"} delay={100} placement={'right'} >
            <button
              className="btn btn-outline-dark btn-lg btn-block"
              disabled={!isFinishedUploading || isLoading || cannotProcess || isFinishedIssuing || isLoading2}
              variant="outline-dark"
              onClick={(event) => {
                event.preventDefault()
                postNotification("Issuing NFT Advertisement 🛠️","Ready to tokenize your advertisement?", "success", 8000)
                callContract(metadataEndpoint, tokenID)
              }}>
                { isFinishedIssuing && !isLoading2 &&
                    <div> 
                      Successfully Issued NFT Advertisement
                    </div>
                }
                {
                  cannotProcess && 
                    <div> 
                      Failed to Issue NFT Advertisement
                    </div>
                }
                { !isFinishedIssuing && !isLoading2 && !cannotProcess &&
                    <div> 
                      Issue NFT Advertisement 🛠️
                    </div>
                }
                { isLoading2 && 
                  <div> 
                    <Spinner animation="border" size="sm" variant="dark" />
                    &nbsp;&nbsp;Issuing NFT Advertisement
                  </div>
                }
            </button>
          </Tippy>
        </Form.Row>
      </Form.Group>
    }
    { isFinishedIssuing &&
      <Form.Group>
        <Form.Row>
          <Form.Label className="text-muted">Congratulations! You've successfully issued your NFT Advertisement. Check out your new token in our <a target="_blank" rel="noreferrer" style={{color: '#CA5010'}} href="https://testnets.opensea.io/collection/blockchain-billboard">NFT Store</a>.</Form.Label>
            <Tippy content={"Etherscan Receipt"} delay={100} placement={'right'} >
              <button
                className="btn btn-outline-success btn-lg btn-block"
                variant="outline-success"
                onClick={() => window.open(etherscanReceipt)}
                >
                Receipt
              </button>
            </Tippy>
          </Form.Row>
      </Form.Group>
    }
    { cannotProcess &&
      <Form.Group>
        <Form.Row>
          <Form.Label className="text-muted">Transaction Failure! Sorry, slot position (#{currentSlot}) no longer available. Please review the following receipt.</Form.Label>
            <Tippy content={"Etherscan Receipt"} delay={100} placement={'right'} >
              <button
                className="btn btn-outline-danger btn-lg btn-block"
                variant="outline-danger"
                onClick={() => window.open(etherscanReceipt)}
                >
                Receipt
              </button>
            </Tippy>
          </Form.Row>
      </Form.Group>
    }
    <br></br>
    </div>
  );
}

class IssueAdvertisementPage extends Component {

  render() {
    return (
        <div>
          {
            this.props.metaMaskNotInstalled &&
              <div>
                <Alert show={true} variant="danger" >
                  Please install MetaMask before issuing your NFT Advertisement. This will be a valuable tool for your new digital assets. Be apart of blockchain internet history!  &nbsp;&nbsp; <i>#TokenizeYourAdvertisement</i> 🖼️
                </Alert>
              </div>
          }
          { this.props.authorized &&
              <div>
                <Alert show={true} variant="success" >
                  Thank you for connecting your wallet. We are delighted that you would consider advertising on the <b>BlockchainBillboard</b>. Be apart of blockchain internet history! 🌎
                </Alert>
              </div>
          }
          {
            !this.props.authorized && !this.props.metaMaskNotInstalled &&
              <div>
                <Alert show={true} variant="success" >
                  Please connect with your wallet before issuing your NFT Advertisement. Limited advertising space available. 100 advertisements for 100 NFTs. &nbsp;&nbsp;<i>#TokenizeYourAdvertisement</i> 🖼️
                </Alert>
                <br></br>
              </div>
          }
          <div style={{lineHeight: '16px'}}>
            <Container>
              {
                this.props.metaMaskNotInstalled &&
                  <div className="App" style={{textAlign: 'center'}}>
                    <br></br>
                    <br></br>
                    <h2>Please install MetaMask... 🦊</h2>
                    <br></br>
                    <img src="https://i.imgur.com/SemOdvB.png" width="150px" height="150px" alt='...'/>
                  </div>
              }
              { this.props.authorized &&
                  <div>
                    <br></br>
                    <h2>Interested in advertising space? Let's issue your NFT Advertisement.</h2>
                    <p className="text-muted">Please note that the following metadata will be attached to your NFT Advertisement forever ❤️</p>
                    <br></br>
                    <hr></hr>
                    <FormExample account={this.props.account} contract={this.props.contract} networkId={this.props.networkId} eth_instance={this.props.eth_instance}></FormExample>
                  </div>
              }
              { !this.props.authorized && !this.props.metaMaskNotInstalled &&
                  <div className="App" style={{textAlign: 'center'}}>
                    <br></br>
                    <h2>Please connect with MetaMask... 🦊</h2>
                    <br></br>
                    <img src="https://i.imgur.com/SemOdvB.png" width="150px" height="150px" alt='...'/>
                  </div>
              }
              { !this.props.authorized &&
                <div>
                  <br></br>
                  <br></br>
                  <br></br>
                  <br></br>
                  <br></br>

                  <div className="row text-center">
                    <div className="col-sm-6">
                      <div className="card">
                        <div className="card-body">
                          <h6 className="card-title font-weight-normal"><b>Learn about NFT Advertisements</b></h6>
                          <p className="card-text font-weight-normal">Prove ownership of your advertisement via a unique token</p>
                          <Link to={'/getting-started'}>
                            <Tippy content={"📚"} delay={100} placement={'bottom'} >
                              <button className="btn btn-outline-dark">NFT Advertisements</button>
                            </Tippy>
                          </Link>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="card">
                        <div className="card-body">
                        <h6 className="card-title font-weight-normal"><b>Explore our NFT Store @ OpenSea</b></h6>
                          <p className="card-text font-weight-normal">Consider exploring other advertisements via our NFT Store</p>
                          <Tippy content={"🏪"} delay={100} placement={'bottom'} >
                            <button className="btn btn-outline-dark" onClick={() => window.open('https://testnets.opensea.io/collection/blockchainbillboard-nfts')}>NFT Store</button>
                          </Tippy>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              }
              </Container>
              {
                !this.props.authorized &&
                <div>
                <br></br>
                  <footer style={{position: 'absolute', bottom: '0', width: '100%', height: '40px', backgroundColor: '#F8F9FA'}}>
                    <Container style={{margin: '11px'}}>
                      {/* <h6>Developed with ❤️ for <a type='text' style={{color: '#CA5010'}} rel="noreferrer" target='_blank' href="https://flippa.com/">AuctionWinner</a> - BlockchainBillboard &copy; 2021</h6> */}
                      <h6>BlockchainBillboard &copy; 2021 - Purchased by Charles via the <a type='text' style={{color: '#CA5010'}} rel="noreferrer" target='_blank' href="https://flippa.com/">Flippa</a> platform.</h6>
                    </Container>
                  </footer>
                </div>
              }
          </div>
        </div>
    );
  }
}

export default IssueAdvertisementPage;