import React, { Component } from 'react';
import { Switch, Route, Link } from 'react-router-dom';
import { withGetScreen } from 'react-getscreen'
import { store } from 'react-notifications-component';
import Tippy from '@tippy.js/react';
import Web3 from 'web3';
import BlockchainBillboard from './build/abis/BlockchainBillboard.json'
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';

import BillBoardPage from './components/BillBoardPage';
import AdvertisingDetailsPage from './components/AdvertisingDetailsPage';
import IssueAdvertisementPage from './components/IssueAdvertisementPage';
import DoesNotExistPage from './components/DoesNotExistPage';

class App extends Component {

  async componentWillMount() {
    this.loadWeb3()
  }
  
  notify() {
    if (!this.state.authenticated) {
      toast.dark("Initial Token Offering: 10 NFTs available for FREE 💸", {
        position: toast.POSITION.BOTTOM_RIGHT,
        hideProgressBar: false,
        pauseOnHover: false,
        draggable: false,
        autoClose: 8000
      });
    }
  }

  postNotification = (title, message, type, duration) => {
    store.addNotification({
      title: title,
      message: message,
      type: type,
      insert: "bottom",
      container: "bottom-left",
      animationIn: ["animate__animated", "animate__fadeIn"],
      animationOut: ["animate__animated", "animate__fadeOut"],
      dismiss: {
        duration: duration,
        onScreen: true
      }
    });
  }
  postNotification1 = (title, message, type, duration) => {
    store.addNotification({
      title: title,
      message: message,
      type: type,
      insert: "bottom",
      container: "bottom-right",
      animationIn: ["animate__animated", "animate__fadeIn"],
      animationOut: ["animate__animated", "animate__fadeOut"],
      dismiss: {
        duration: duration,
        onScreen: true
      }
    });
  }

  constructor(props) {
    super(props)
    this.state = {
      account: null,
      eth_instance: null,
      contract: null,
      networkId: null,
      problemConnecting: false,
      metaMaskNotInstalled: false,
      authenticated: false,
    }
    this.signInPrompt = this.signInPrompt.bind(this)
  }

  async loadBlockchainData() {
    window.web3 = new Web3(window.ethereum)
    const accounts = await window.web3.eth.getAccounts()
    this.setState({account: accounts[0]})
    console.log(this.state.account)
    const networkId = await window.web3.eth.net.getId()
    console.log(networkId)
    if (networkId == 4) {
      this.postNotification("Connected to Rinkeby ⚡", "Interfacing with the Rinkeby Test Net", "success", 5500)
    } else {
      this.postNotification("Disconnected from Rinkeby ⚡", "Please use the Rinkeby Test Net", "danger", 5500)
    }
    this.setState({networkId})
    const networkData = BlockchainBillboard.networks[networkId]

    if (networkData) {
      const abi = BlockchainBillboard.abi
      const address = networkData.address
      const contract = new window.web3.eth.Contract(abi, address)
      this.setState({ contract })
    }
    this.setState({eth_instance: window.web3})
    console.log(this.state)
  }

  async loadWeb3() {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length > 0){
          if (this.state.authenticated) {
            this.postNotification("Switched to a different account 🧍", "Account successfully connected", "info", 5500)
          } 
          this.setState({account: accounts[0]})
          this.setState({authenticated: true})
          console.log(accounts[0])
        } else {
          this.setState({account: null})
          this.setState({contract: null})
          this.setState({networkId: null})
          this.setState({authenticated: false})
          this.postNotification("Disconnected from Rinkeby ⚡", "Successfully disconnected", "danger", 5500)
        }
      })
      window.ethereum.on('chainChanged', (chainId) => {
        if (chainId){
          if (chainId == 4) {
            this.postNotification("Connected to Rinkeby ⚡", "Interfacing with the Rinkeby Test Net", "success", 5500)
          } else {
            this.postNotification("Disconnected from Rinkeby ⚡", "Please use the Rinkeby Test Net", "danger", 5500)
          }
          this.setState({networkId: chainId})
        }
      })
      try {
        await window.ethereum.request({method: 'eth_requestAccounts'})
        this.setState({authenticated: true})
        console.log(this.state.authenticated)
        this.loadBlockchainData()
      } catch(error) {
        this.setState({authenticated: false})
        console.log(this.state.authenticated)
        this.notify()
        console.log(error)
      }
    } else {
      this.setState({metaMaskNotInstalled: true})
      this.notify()
    }
  }

  async signInPrompt() {
    await window.ethereum.request({
      method: 'eth_requestAccounts'
    })
    .then(() => {
      this.setState({authenticated: true})
      this.loadBlockchainData()
    })
    .catch((error) => {
      console.log('d', error.code)
      if (error.code === -32002) {                // Request of type 'wallet_requestPermissions' already pending
        this.postNotification("Please open MetaMask extension 😲", "Chrome extension notification", "danger", 5500)
        this.setState({problemConnecting: true})
      }
    })
  }

  render() {
    if (this.props.isMobile() || this.props.isTablet()) {
      return (
          <>
              <div className="jumbotron text-center">
                <h2 className="font-weight-normal"><b>BlockchainBillboard</b> 🐎</h2>
                <p className="font-weight-normal"><b>NFT-backed digital advertising</b></p>
              </div>
              <h6 style={{textAlign:'center'}}>Please use your laptop/computer instead...</h6>
              <br />
              <h6 style={{textAlign:'center'}}>Thanks for understanding! ❤️</h6>
              <br />
              <div style={{textAlign: 'center'}}>
                <img alt='...' src='https://i.imgur.com/lENsOfI.png' style={{width: '75%', height: '75%'}}></img>
              <br />
              <br />
              <h6><i>blockchainbillboard.io</i></h6>
              </div>
          </>
        )
    } else {
      const loggedIn = this.state.authenticated;
      const problemDetected = this.state.problemConnecting;
      const metaMaskNotInstalled = this.state.metaMaskNotInstalled;
      return (
          <> 
              <div className='App'>
                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <Link to="/" passHref><a href="/" className="navbar-brand"><b>BlockchainBillboard</b> 🐎</a></Link>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mr-auto">
                          <Tippy content={"📚"} delay={100} placement={'bottom'} >
                            <li className="nav-item">
                              <Link to="/getting-started" passHref><a href="/getting-started" className="nav-link active"> Getting Started</a></Link>
                            </li>
                          </Tippy>
                          <Tippy content={"🛠️"} delay={100} placement={'bottom'} >
                            <li className="nav-item">
                              <Link to="/issue-advertisement" passHref><a href="/issue-advertisement" className="nav-link active"> Issue Advertisement</a></Link>
                            </li>
                          </Tippy>
                          <Tippy content={"🏪"} delay={100} placement={'bottom'} >
                            <li className="nav-item">
                              <a target="_blank" rel="noreferrer" className="nav-link active" href="https://testnets.opensea.io/collection/blockchainbillboard-nfts"> NFT Store</a>
                            </li>
                          </Tippy>
                          <Tippy content={"📧"} delay={100} placement={'bottom'} >
                            <li className="nav-item">
                            <a target="_blank" rel="noreferrer" className="nav-link active" href="mailto:contact@blockchainbillboard.io?&subject=The%20subject%20of%20the%20email&body=The%20body%20of%20the%20email"> Contact Us</a>
                            </li>
                          </Tippy>
                        </ul>
  
                        {
                          !loggedIn
                            ? !problemDetected
                                ? metaMaskNotInstalled 
                                  ? ( <Tippy content={"🚀"} delay={100} placement={'bottom'} >
                                        <form className="form-inline my-2 my-lg-0">
                                          <div className="row">
                                            <a className="btn btn-outline-dark" href="https://metamask.io/" target="_blank" rel="noreferrer" role="button">
                                              <img width="20px" alt="MetaMask Connect" src="https://i.imgur.com/SemOdvB.png" />
                                              &nbsp;&nbsp;Install MetaMask
                                            </a>
                                            <p>&nbsp;&nbsp;</p>
                                          </div>
                                        </form> 
                                    </Tippy>)
                                : ( <Tippy content={"Connect w/ MetaMask ❤️"} delay={100} placement={'bottom'} >
                                      <form className="form-inline my-2 my-lg-0">
                                            <div className="row">
                                              <a className="btn btn-outline-dark " onClick={this.signInPrompt} role="button">
                                                <img width="20px" alt="MetaMask Connect" src="https://i.imgur.com/SemOdvB.png" />
                                                &nbsp;&nbsp;Connect
                                              </a>
                                              <p>&nbsp;&nbsp;</p>
                                            </div>
                                          </form> 
                                  </Tippy>
                                )
                            : ( <Tippy content={"Please open MetaMask extension 😲"} delay={100} placement={'bottom'} >
                                      <form className="form-inline my-2 my-lg-0">
                                            <div className="row">
                                              <a className="btn btn-outline-dark " onClick={this.signInPrompt} role="button">
                                                <img width="20px" alt="MetaMask Connect" src="https://i.imgur.com/SemOdvB.png" />
                                                &nbsp;&nbsp;Connect
                                              </a>
                                              <p>&nbsp;&nbsp;</p>
                                            </div>
                                        </form> 
                                </Tippy>
                            )
                          : ( <a>
                                <i><b>Your Account:</b> {this.state.account}</i> &nbsp;
                                  <Tippy content={"Connected 😊"} delay={150} placement={'bottom'} >  
                                    <span>✔️</span>
                                  </Tippy>
                              </a>
                            )
                        }
                    </div>
                </nav>
                <ToastContainer />
                <Switch>
                  <Route exact path='/' component={() => <BillBoardPage authorized={loggedIn} account={this.state.account} />} />
                  <Route path='/getting-started' component={() => <AdvertisingDetailsPage authorized={loggedIn} />} />
                  <Route path='/issue-advertisement' component={() => <IssueAdvertisementPage authorized={loggedIn} metaMaskNotInstalled={metaMaskNotInstalled} account={this.state.account} contract={this.state.contract} networkId={this.state.networkId} eth_instance={this.state.eth_instance} />} />
                  <Route path='/*' component={() => <DoesNotExistPage />} />
                </Switch>
              </div>
          </>
      );
    }
  } 
}

export default withGetScreen(App);
